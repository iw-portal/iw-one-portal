import { useEffect, useState } from "react";
import { supabase } from "../../../../lib/supabase";

export default function Attendance({ user }) {
  const [programs, setPrograms] = useState([]);
  const [selectedProgram, setSelectedProgram] = useState("");

  const [attendanceDate, setAttendanceDate] = useState(
    new Date().toISOString().split("T")[0],
  );

  const [students, setStudents] = useState([]);

  const [saving, setSaving] = useState(false);

  const [history, setHistory] = useState([]);

  useEffect(() => {
    if (user?.person_id) {
      loadPrograms();
    }
  }, [user]);

  useEffect(() => {
    if (selectedProgram) {
      loadRoster();
      loadHistory();
    }
  }, [selectedProgram, attendanceDate]);

  const loadPrograms = async () => {
    const { data } = await supabase
      .from("programs")
      .select("*")
      .or(`lead_id.eq.${user.person_id},co_lead_id.eq.${user.person_id}`)
      .order("course_title");

    setPrograms(data || []);

    if (data?.length) {
      setSelectedProgram(data[0].id);
    }
  };

  const loadRoster = async () => {
    const { data } = await supabase
      .from("enrollments")
      .select(
        `
        id,
        student_id,
        people:student_id(
          id,
          fname,
          lname,
          email
        )
      `,
      )
      .eq("program_id", selectedProgram);

    const { data: existingAttendance } = await supabase
      .from("attendance")
      .select("*")
      .eq("program_id", selectedProgram)
      .eq("attendance_date", attendanceDate);

    const attendanceMap = {};

    existingAttendance?.forEach((a) => {
      attendanceMap[a.student_id] = a;
    });

    const roster =
      data?.map((student) => ({
        ...student,
        status:
          attendanceMap[student.student_id]?.attendance_status || "present",
      })) || [];

    setStudents(roster);
  };

  const loadHistory = async () => {
    const { data } = await supabase
      .from("attendance")
      .select("*")
      .eq("program_id", selectedProgram)
      .order("attendance_date", {
        ascending: false,
      });

    setHistory(data || []);
  };

  const updateStatus = (studentId, status) => {
    setStudents((prev) =>
      prev.map((s) => (s.student_id === studentId ? { ...s, status } : s)),
    );
  };

  const bulkUpdate = (status) => {
    setStudents((prev) =>
      prev.map((s) => ({
        ...s,
        status,
      })),
    );
  };

  const saveAttendance = async () => {
    try {
      setSaving(true);

      for (const student of students) {
        const { data: existing } = await supabase
          .from("attendance")
          .select("id")
          .eq("student_id", student.student_id)
          .eq("program_id", selectedProgram)
          .eq("attendance_date", attendanceDate)
          .maybeSingle();

        if (existing) {
          await supabase
            .from("attendance")
            .update({
              attendance_status: student.status,
              marked_by: user.person_id,
              updated_at: new Date(),
            })
            .eq("id", existing.id);
        } else {
          await supabase.from("attendance").insert({
            enrollment_id: student.id,
            student_id: student.student_id,
            program_id: selectedProgram,
            attendance_date: attendanceDate,
            attendance_status: student.status,
            marked_by: user.person_id,
          });
        }
      }

      alert("Attendance saved successfully");

      loadHistory();
    } finally {
      setSaving(false);
    }
  };

  const summary = {
    present: students.filter((s) => s.status === "present").length,

    absent: students.filter((s) => s.status === "absent").length,

    excused: students.filter((s) => s.status === "excused").length,

    holiday: students.filter((s) => s.status === "holiday").length,
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl border shadow-sm p-8">
        <h1 className="text-4xl font-bold text-[#0f5b54]">Attendance</h1>

        <p className="text-gray-500 mt-2">
          Track student and volunteer attendance.
        </p>
      </div>

      <div className="bg-white rounded-3xl border shadow-sm p-6">
        <div className="grid md:grid-cols-2 gap-4">
          <select
            value={selectedProgram}
            onChange={(e) => setSelectedProgram(e.target.value)}
            className="border rounded-xl p-3"
          >
            {programs.map((program) => (
              <option key={program.id} value={program.id}>
                <option key={program.id} value={program.id}>
                  {program.course_title}
                  {program.level
                    ? ` • ${program.level.charAt(0).toUpperCase()}${program.level.slice(1)}`
                    : ""}
                </option>
              </option>
            ))}
          </select>

          <input
            type="date"
            value={attendanceDate}
            onChange={(e) => setAttendanceDate(e.target.value)}
            className="border rounded-xl p-3"
          />
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        <Card title="Present" value={summary.present} color="text-green-600" />

        <Card title="Absent" value={summary.absent} color="text-red-600" />

        <Card title="Excused" value={summary.excused} color="text-yellow-600" />

        <Card title="Holiday" value={summary.holiday} color="text-blue-600" />
      </div>

      <div className="bg-white rounded-3xl border shadow-sm p-6">
        <div className="flex flex-wrap gap-3 mb-6">
          <button
            onClick={() => bulkUpdate("present")}
            className="bg-green-600 text-white px-4 py-2 rounded-xl"
          >
            Mark All Present
          </button>

          <button
            onClick={() => bulkUpdate("absent")}
            className="bg-red-600 text-white px-4 py-2 rounded-xl"
          >
            Mark All Absent
          </button>

          <button
            onClick={() => bulkUpdate("excused")}
            className="bg-yellow-500 text-white px-4 py-2 rounded-xl"
          >
            Mark All Excused
          </button>

          <button
            onClick={() => bulkUpdate("holiday")}
            className="bg-blue-600 text-white px-4 py-2 rounded-xl"
          >
            Holiday
          </button>
        </div>

        <table className="w-full">
          <thead>
            <tr className="border-b bg-gray-50">
              <th className="text-left p-4">Name</th>

              <th className="text-left p-4">Email</th>

              <th className="text-left p-4">Status</th>
            </tr>
          </thead>

          <tbody>
            {students.map((student) => (
              <tr key={student.student_id} className="border-b">
                <td className="p-4">
                  {student.people?.fname} {student.people?.lname}
                </td>

                <td className="p-4">{student.people?.email}</td>

                <td className="p-4">
                  <select
                    value={student.status}
                    onChange={(e) =>
                      updateStatus(student.student_id, e.target.value)
                    }
                    className="border rounded-lg px-3 py-2"
                  >
                    <option value="present">Present</option>

                    <option value="absent">Absent</option>

                    <option value="excused">Excused</option>

                    <option value="holiday">Holiday</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <button
          onClick={saveAttendance}
          disabled={saving}
          className="mt-6 bg-[#0f5b54] text-white px-6 py-3 rounded-xl"
        >
          {saving ? "Saving..." : "Save Attendance"}
        </button>
      </div>

      <div className="bg-white rounded-3xl border shadow-sm p-8">
        <h2 className="text-2xl font-bold mb-6">Attendance History</h2>

        <div className="max-h-[400px] overflow-y-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-gray-50">
                <th className="text-left p-4">Date</th>

                <th className="text-left p-4">Status</th>
              </tr>
            </thead>

            <tbody>
              {history.map((row) => (
                <tr key={row.id} className="border-b">
                  <td className="p-4">{row.attendance_date}</td>

                  <td className="p-4 capitalize">{row.attendance_status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Card({ title, value, color }) {
  return (
    <div className="bg-white rounded-3xl border shadow-sm p-6">
      <div className="text-sm text-gray-500">{title}</div>

      <div className={`text-4xl font-bold mt-2 ${color}`}>{value}</div>
    </div>
  );
}
