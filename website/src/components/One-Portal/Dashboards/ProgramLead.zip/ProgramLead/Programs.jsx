import { useEffect, useState } from "react";
import { supabase } from "../../../../lib/supabase";

export default function Programs({ user }) {
  const [programs, setPrograms] = useState([]);
  const [selectedProgram, setSelectedProgram] = useState(null);
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState("");
  const [showEmailModal, setShowEmailModal] = useState(false);

  const [selectedTemplate, setSelectedTemplate] = useState("inclusive");

  const [emailSubject, setEmailSubject] = useState("");

  const [emailBody, setEmailBody] = useState("");
  const [canvasLink, setCanvasLink] = useState("");

  const [meetingLink, setMeetingLink] = useState("");

  const [meetingLocation, setMeetingLocation] = useState("");

  const [meetingTime, setMeetingTime] = useState("");

  const [leadName, setLeadName] = useState("");
  const [coLeadName, setCoLeadName] = useState("");
  const [signedBy, setSignedBy] = useState("");

  const [meetingDate, setMeetingDate] = useState("");
  const [additionalNotes, setAdditionalNotes] = useState("");

  useEffect(() => {
    if (user?.person_id) {
      fetchPrograms();
    }
  }, [user?.person_id]);

  const fetchPrograms = async () => {
    const { data, error } = await supabase
      .from("programs")
      .select("*")
      .or(`lead_id.eq.${user.person_id},co_lead_id.eq.${user.person_id}`)
      .order("course_title");

    if (error) {
      console.error(error);
      return;
    }

    setPrograms(data || []);
  };

  const fetchStudents = async (programId) => {
    const { data, error } = await supabase
      .from("enrollments")
      .select(
        `
        *,
        people:student_id(
          id,
          fname,
          lname,
          email
        ),
        program_member_support(
          id,
          buddy_id,
          support_notes
        )
      `,
      )
      .eq("program_id", programId);

    if (error) {
      console.error(error);
      return;
    }

    setStudents(data || []);
  };

  const loadProgramLeads = async (program) => {
    let lead = "";
    let coLead = "";

    if (program.lead_id) {
      const { data } = await supabase
        .from("people")
        .select("fname,lname")
        .eq("id", program.lead_id)
        .maybeSingle();

      if (data) {
        lead = `${data.fname} ${data.lname}`;
      }
    }

    if (program.co_lead_id) {
      const { data } = await supabase
        .from("people")
        .select("fname,lname")
        .eq("id", program.co_lead_id)
        .maybeSingle();

      if (data) {
        coLead = `${data.fname} ${data.lname}`;
      }
    }

    setLeadName(lead);
    setCoLeadName(coLead);
    setSignedBy(lead);
  };

  const introSection = ({ programName, leadName, coLeadName }) => {
    if (coLeadName) {
      return `
      Welcome to the <strong>${programName}</strong> class!

      <br/><br/>

      My name is <strong>${leadName}</strong>, and I am one of the instructors.

      Along with me, <strong>${coLeadName}</strong> will also be supporting this program.
    `;
    }

    return `
    Welcome to the <strong>${programName}</strong> class!

    <br/><br/>

    My name is <strong>${leadName}</strong>, and I will be your instructor for this program.
  `;
  };

  const meetingSection = ({
    meetingDate,
    meetingTime,
    meetingLocation,
    meetingLink,
  }) => {
    let html = "";

    if (meetingDate) {
      html += `
      <strong>Meeting Date:</strong>
      ${meetingDate}<br/>
    `;
    }

    if (meetingTime) {
      html += `
      <strong>Meeting Time:</strong>
      ${meetingTime}<br/>
    `;
    }

    if (meetingLocation) {
      html += `
      <strong>Location:</strong>
      ${meetingLocation}<br/>
    `;
    }

    if (meetingLink) {
      html += `
      <strong>Meeting Link:</strong>
      <a href="${meetingLink}">
        ${meetingLink}
      </a><br/>
    `;
    }

    return html;
  };

  const canvasSection = ({ canvasLink }) => {
    if (!canvasLink) {
      return "";
    }

    return `
    <div
      style="
        margin-top:32px;
        color:#0c4f49;
        font-size:18px;
        font-weight:bold;
      "
    >
      Canvas Course
    </div>

    <div
      style="
        color:#5d6c69;
        font-size:15px;
        line-height:30px;
        margin-top:10px;
      "
    >
      All coursework information
      will be available on Canvas.

      <br/><br/>

      <a href="${canvasLink}">
        ${canvasLink}
      </a>
    </div>
  `;
  };

  const materialsSection = () => `
<div
  style="
    margin-top:32px;
    color:#0c4f49;
    font-size:18px;
    font-weight:bold;
  "
>
Materials Needed
</div>

<div
  style="
    color:#5d6c69;
    font-size:15px;
    line-height:30px;
    margin-top:10px;
  "
>
• Laptop (Windows or Mac)<br/>
• External Mouse<br/>
• Power Charging Cables
</div>
`;

  const notesSection = ({ additionalNotes }) => {
    if (!additionalNotes) {
      return "";
    }

    return `
    <div
      style="
        margin-top:32px;
        color:#0c4f49;
        font-size:18px;
        font-weight:bold;
      "
    >
      Additional Notes
    </div>

    <div
      style="
        margin-top:12px;
        color:#5d6c69;
        line-height:30px;
      "
    >
      ${additionalNotes}
    </div>
  `;
  };

  const signatureSection = ({ signedBy, instructorEmail }) => `
<div
  style="
    margin-top:42px;
    color:#667572;
    font-size:15px;
    line-height:28px;
  "
>
Thanks,
<br/><br/>

<strong>${signedBy}</strong>

${instructorEmail ? `<br/>Email: ${instructorEmail}` : ""}
</div>
`;

  const templateConfig = {
    welcome: {
      banner: "CLASS WELCOME EMAIL",
      title: (programName) => `Welcome to ${programName}`,
      showMeetingInfo: true,
      showMaterials: true,
      showCanvas: true,
      showNotes: true,
      closing:
        "We are very excited for our journey together and look forward to meeting everyone soon.",
    },

    inclusive: {
      banner: "INCLUSIVE WORLD COMMUNICATION",
      title: () => emailSubject || "Inclusive World Update",
      showMeetingInfo: false,
      showMaterials: false,
      showCanvas: false,
      showNotes: true,
      closing: "Thank you for being part of the Inclusive World community.",
    },

    reminder: {
      banner: "CLASS REMINDER",
      title: (programName) => `${programName} Reminder`,
      showMeetingInfo: true,
      showMaterials: false,
      showCanvas: false,
      showNotes: true,
      closing: "Please reach out if you have any questions before class.",
    },
  };

  const generatePreview = () => {
    const config = templateConfig[selectedTemplate];

    const introHtml =
      selectedTemplate === "welcome"
        ? coLeadName
          ? `
        Welcome to the <strong>${selectedProgram?.course_title}</strong> class!

        <br/><br/>

        My name is <strong>${leadName}</strong>, and I am one of the instructors.

        Along with me,
        <strong>${coLeadName}</strong>
        will also be supporting this program.
      `
          : `
        Welcome to the <strong>${selectedProgram?.course_title}</strong> class!

        <br/><br/>

        My name is <strong>${leadName}</strong>, and I will be your instructor for this program.
      `
        : `
        Hello Everyone,
      `;

    return `
  <table
    role="presentation"
    width="100%"
    cellpadding="0"
    cellspacing="0"
    border="0"
    bgcolor="#f4f8f7"
  >
    <tr>
      <td align="center" style="padding:40px 16px;">

        <table
  role="presentation"
  width="100%"
  style="
    max-width:620px;
    width:100%;
    border-radius:24px;
    overflow:hidden;
    border:1px solid #e4ece9;
    font-family:Arial,Helvetica,sans-serif;
    table-layout:fixed;
  "
        >

          <tr>
            <td
              bgcolor="#0c4f49"
              align="center"
              style="padding:50px 36px;"
            >

              <img
                src="https://res.cloudinary.com/ddcxejrmd/image/upload/v1779491649/Screenshot_2026-05-22_at_4.12.36_PM_qp5x6k-removebg-preview_nefqzi.png"
                width="72"
                style="display:block;margin-bottom:24px;"
              />

              <div
                style="
                  color:#d7efeb;
                  font-size:12px;
                  font-weight:bold;
                  letter-spacing:1.6px;
                  margin-bottom:18px;
                "
              >
                ${config.banner}
              </div>

              <div
                style="
                  color:#ffffff;
                  font-size:36px;
                  line-height:44px;
                  font-weight:bold;
                "
              >
                ${config.title(selectedProgram?.course_title)}
              </div>

            </td>
          </tr>

          <tr>
            <td style="padding:42px 36px;">

              <div
                style="
                  color:#5d6c69;
                  font-size:16px;
                  line-height:30px;
                "
              >
                ${introHtml}
              </div>

                            ${
                              emailBody
                                ? `
                <div
  style="
    color:#5d6c69;
    font-size:15px;
    line-height:20px;
    white-space:pre-wrap;
    overflow-wrap:break-word;
    word-break:break-word;
  "
>
  ${emailBody}
</div>
              `
                                : ""
                            }

              ${
                config.showMeetingInfo
                  ? `
                <table
                  role="presentation"
                  width="100%"
                  cellpadding="0"
                  cellspacing="0"
                  border="0"
                  bgcolor="#f8fbfa"
                  style="
                    margin-top:34px;
                    border-radius:18px;
                    border:1px solid #e5efec;
                  "
                >
                  <tr>
                    <td style="padding:28px;">

                      <div
                        style="
                          color:#0c4f49;
                          font-size:20px;
                          font-weight:bold;
                          margin-bottom:12px;
                        "
                      >
                        Class Information
                      </div>

                      <div
                        style="
                          color:#61706d;
                          font-size:15px;
                          line-height:30px;
                        "
                      >
                        ${
                          meetingDate
                            ? `<strong>Date:</strong> ${meetingDate}<br/>`
                            : ""
                        }

                        ${
                          meetingTime
                            ? `<strong>Time:</strong> ${meetingTime}<br/>`
                            : ""
                        }

                        ${
                          meetingLocation
                            ? `<strong>Location:</strong> ${meetingLocation}<br/>`
                            : ""
                        }

                        ${
                          meetingLink
                            ? `<strong>Meeting Link:</strong>
                               <a href="${meetingLink}">
                                 ${meetingLink}
                               </a><br/>`
                            : ""
                        }
                      </div>

                    </td>
                  </tr>
                </table>
              `
                  : ""
              }

              ${
                config.showMaterials
                  ? `
                <div
                  style="
                    margin-top:32px;
                    color:#0c4f49;
                    font-size:18px;
                    font-weight:bold;
                  "
                >
                  Materials Needed
                </div>

                <div
                  style="
                    color:#5d6c69;
                    font-size:15px;
                    line-height:30px;
                    margin-top:10px;
                  "
                >
                  • Laptop (Windows or Mac)<br/>
                  • External Mouse<br/>
                  • Power Charging Cables
                </div>
              `
                  : ""
              }

              ${
                config.showCanvas && canvasLink
                  ? `
                <div
                  style="
                    margin-top:32px;
                    color:#0c4f49;
                    font-size:18px;
                    font-weight:bold;
                  "
                >
                  Canvas Course
                </div>

                <div
                  style="
                    color:#5d6c69;
                    font-size:15px;
                    line-height:30px;
                    margin-top:10px;
                  "
                >
                  <a href="${canvasLink}">
                    ${canvasLink}
                  </a>
                </div>
              `
                  : ""
              }



              ${
                config.showNotes && additionalNotes
                  ? `
                <div
                  style="
                    margin-top:32px;
                    color:#0c4f49;
                    font-size:18px;
                    font-weight:bold;
                  "
                >
                  Additional Notes
                </div>

                <div
                  style="
                    margin-top:12px;
                    color:#5d6c69;
                    line-height:30px;
                  "
                >
                  ${additionalNotes}
                </div>
              `
                  : ""
              }

              <div
                style="
                  margin-top:42px;
                  color:#667572;
                  font-size:15px;
                  line-height:28px;
                "
              >
                ${config.closing}
              </div>

              <div
                style="
                  margin-top:42px;
                  color:#667572;
                  font-size:15px;
                  line-height:28px;
                "
              >
                Thanks,
                <br/><br/>

                <strong>${signedBy}</strong>

                ${user?.email ? `<br/>Email: ${user.email}` : ""}
              </div>

            </td>
          </tr>

        </table>

      </td>
    </tr>
  </table>
  `;
  };

  const sendEmail = async () => {
    try {
      const recipients = students
        .filter((s) => s.people?.email)
        .map((s) => ({
          email: s.people.email,
          name: `${s.people.fname} ${s.people.lname}`,
        }));
      const senderName = `Inclusive World - ${selectedProgram.course_title} (${selectedProgram.level.charAt(0).toUpperCase()}${selectedProgram.level.slice(1)}) Leads`;
      const receiverName = `Inclusive World - ${selectedProgram.course_title} (${selectedProgram.level.charAt(0).toUpperCase()}${selectedProgram.level.slice(1)})`;

      const response = await fetch("/api/program_email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          recipients,
          subject: emailSubject,
          htmlContent: generatePreview(),
          senderName: senderName,
          receiverName: receiverName,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to send email");
      }

      alert("Email sent successfully");
      setShowEmailModal(false);
    } catch (err) {
      console.error(err);
      alert("Failed to send email");
    }
  };

  const updateSupport = async (enrollmentId, buddyId, notes) => {
    const existing = students.find((s) => s.id === enrollmentId)
      ?.program_member_support?.[0];

    if (existing) {
      await supabase
        .from("program_member_support")
        .update({
          buddy_id: buddyId,
          support_notes: notes,
          updated_at: new Date(),
        })
        .eq("id", existing.id);
    } else {
      await supabase.from("program_member_support").insert({
        enrollment_id: enrollmentId,
        buddy_id: buddyId,
        support_notes: notes,
      });
    }

    fetchStudents(selectedProgram.id);
  };

  const filteredPrograms = programs.filter(
    (p) =>
      p.course_title?.toLowerCase().includes(search.toLowerCase()) ||
      p.description?.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl border shadow-sm p-8">
        <h1 className="text-4xl font-bold text-[#0f5b54]">Programs</h1>

        <p className="text-gray-500 mt-2">
          Manage enrolled students, buddy assignments, support needs, and
          communication.
        </p>
      </div>

      <div className="bg-white rounded-3xl border shadow-sm p-6">
        <input
          placeholder="Search programs..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full border rounded-xl px-4 py-3"
        />
      </div>

      <div className="bg-white rounded-3xl border shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-100">
            <tr>
              <th className="text-left p-4">Program</th>
              <th className="text-left p-4">Academic Year</th>
              <th className="text-left p-4">Duration</th>
              <th className="text-left p-4">Status</th>
              <th className="text-left p-4">Actions</th>
            </tr>
          </thead>

          <tbody>
            {filteredPrograms.map((program) => (
              <tr key={program.id} className="border-t">
                <td className="p-4">{program.course_title}</td>

                <td className="p-4">{program.academic_year}</td>

                <td className="p-4">{program.duration}</td>

                <td className="p-4">
                  {program.is_active ? "Current" : "Completed"}
                </td>

                <td className="p-4">
                  <button
                    onClick={() => {
                      setSelectedProgram(program);
                      fetchStudents(program.id);
                      loadProgramLeads(program);
                    }}
                    className="bg-[#0f5b54] text-white px-4 py-2 rounded-lg"
                  >
                    View Students
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedProgram && (
        <div className="bg-white rounded-3xl border shadow-sm p-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold">
                {selectedProgram.course_title}
              </h2>

              <p className="text-gray-500">Student Roster</p>
            </div>

            <button
              onClick={() => setShowEmailModal(true)}
              className="bg-blue-600 text-white px-5 py-2 rounded-lg"
            >
              Email Entire Class
            </button>
          </div>

          <div className="space-y-4">
            {students.map((student) => {
              const support = student.program_member_support?.[0];

              return (
                <div key={student.id} className="border rounded-xl p-4">
                  <h3 className="font-semibold">
                    {student.people?.fname} {student.people?.lname}
                  </h3>

                  <p className="text-sm text-gray-500">
                    {student.people?.email}
                  </p>

                  <textarea
                    defaultValue={support?.support_notes || ""}
                    placeholder="Support notes..."
                    className="w-full border rounded-lg p-3 mt-3"
                    onBlur={(e) =>
                      updateSupport(
                        student.id,
                        support?.buddy_id,
                        e.target.value,
                      )
                    }
                  />
                </div>
              );
            })}
            {showEmailModal && (
              <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl w-full max-w-7xl h-[90vh] flex overflow-hidden shadow-2xl">
                  {/* LEFT PANEL */}

                  <div className="w-[420px] border-r bg-gray-50 p-6 overflow-y-auto">
                    <h2 className="text-2xl font-bold text-[#0f5b54] mb-2">
                      Email Designer
                    </h2>

                    <p className="text-sm text-gray-500 mb-6">
                      Select a template and customize the email before sending.
                    </p>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Template
                        </label>

                        <select
                          value={selectedTemplate}
                          onChange={(e) => setSelectedTemplate(e.target.value)}
                          className="w-full border rounded-xl p-3"
                        >
                          <option value="inclusive">
                            Inclusive World Template
                          </option>

                          <option value="welcome">Welcome Email</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Subject
                        </label>

                        <input
                          value={emailSubject}
                          onChange={(e) => setEmailSubject(e.target.value)}
                          className="w-full border rounded-xl p-3"
                          placeholder="Email Subject"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Program
                        </label>

                        <input
                          value={selectedProgram?.course_title || ""}
                          disabled
                          className="w-full border rounded-xl p-3 bg-gray-100"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Lead Name
                        </label>

                        <input
                          value={leadName}
                          onChange={(e) => setLeadName(e.target.value)}
                          className="w-full border rounded-xl p-3"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Co-Lead Name
                        </label>

                        <input
                          value={coLeadName}
                          onChange={(e) => setCoLeadName(e.target.value)}
                          className="w-full border rounded-xl p-3"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Message
                        </label>

                        <textarea
                          rows={8}
                          value={emailBody}
                          onChange={(e) => setEmailBody(e.target.value)}
                          className="
    w-full
    border
    rounded-xl
    p-3
    resize-y
    break-words
  "
                        />
                      </div>

                      {selectedTemplate === "welcome" && (
                        <>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Meeting Date
                            </label>

                            <input
                              type="date"
                              value={meetingDate}
                              onChange={(e) => setMeetingDate(e.target.value)}
                              className="w-full border rounded-xl p-3"
                            />
                          </div>

                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Meeting Time
                            </label>

                            <input
                              value={meetingTime}
                              onChange={(e) => setMeetingTime(e.target.value)}
                              className="w-full border rounded-xl p-3"
                              placeholder="6:00 PM PST"
                            />
                          </div>

                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Meeting Location
                            </label>

                            <input
                              value={meetingLocation}
                              onChange={(e) =>
                                setMeetingLocation(e.target.value)
                              }
                              className="w-full border rounded-xl p-3"
                            />
                          </div>

                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Meeting Link
                            </label>

                            <input
                              value={meetingLink}
                              onChange={(e) => setMeetingLink(e.target.value)}
                              className="w-full border rounded-xl p-3 mb-2"
                            />
                          </div>

                          <div>
                            <label className="block text-sm font-medium mb-2">
                              LMS Course Link (Optional)
                            </label>

                            <input
                              placeholder="LMS Course Link (Optional)"
                              value={canvasLink}
                              onChange={(e) => setCanvasLink(e.target.value)}
                              className="w-full border rounded-xl p-3"
                            />
                          </div>

                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Additional Notes
                            </label>

                            <textarea
                              rows={4}
                              value={additionalNotes}
                              onChange={(e) =>
                                setAdditionalNotes(e.target.value)
                              }
                              className="w-full border rounded-xl p-3"
                            />
                          </div>
                        </>
                      )}

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Signed By
                        </label>

                        <input
                          value={signedBy}
                          onChange={(e) => setSignedBy(e.target.value)}
                          className="w-full border rounded-xl p-3"
                        />
                      </div>
                    </div>
                  </div>

                  {/* RIGHT PANEL */}

                  <div className="flex-1 bg-gray-100 overflow-y-auto p-8">
                    <h2 className="text-2xl font-bold text-[#0f5b54] mb-6">
                      Live Preview
                    </h2>

                    <div
                      className="
    bg-white
    rounded-2xl
    shadow-xl
    max-w-4xl
    w-full
    mx-auto
    p-10
    overflow-hidden
  "
                    >
                      <div
                        className="overflow-x-auto"
                        dangerouslySetInnerHTML={{
                          __html: generatePreview(),
                        }}
                      />
                    </div>
                  </div>

                  {/* ACTIONS */}

                  <div className="absolute bottom-8 right-8 flex gap-3">
                    <button
                      onClick={() => setShowEmailModal(false)}
                      className="px-6 py-3 border rounded-xl"
                    >
                      Cancel
                    </button>

                    <button
                      onClick={sendEmail}
                      className="px-6 py-3 bg-[#0f5b54] text-white rounded-xl"
                    >
                      Send Email
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
