import { useEffect, useState } from "react";
import { supabase } from "../../../../lib/supabase";
import { LuInfo } from "react-icons/lu";

const MetricCard = ({ title, value }) => (
  <div className="bg-white rounded-xl shadow p-6">
    <p className="text-gray-500 text-sm mb-2">{title}</p>

    <p className="text-3xl font-bold text-[#0f5b54]">{value}</p>
  </div>
);

const ProgramLeadDashboard = ({ user }) => {
  const [notifications, setNotifications] = useState([]);

  const [metrics, setMetrics] = useState({
    currentPrograms: 0,
    completedPrograms: 0,
    totalStudents: 0,
    totalVolunteers: 0,
    attendanceAverage: 0,
    pendingBuddyAssignments: 0,
    activeNotifications: 0,
  });

  const role = user?.role;

  useEffect(() => {
    if (role) {
      fetchNotifications();
    }

    if (user?.person_id) {
      fetchMetrics();
    }
  }, [role, user?.person_id]);

  const fetchNotifications = async () => {
    const nowPT = new Date(
      new Date().toLocaleString("en-US", {
        timeZone: "America/Los_Angeles",
      }),
    );

    const { data, error } = await supabase
      .from("notifications")
      .select("*")
      .in("role_target", ["all", role])
      .order("created_at", {
        ascending: false,
      });

    if (error) {
      console.error(error);
      return;
    }

    const filtered = (data || []).filter((n) => {
      const expiry = new Date(`${n.expires_at}`);

      return nowPT < expiry;
    });

    setNotifications(filtered);

    setMetrics((prev) => ({
      ...prev,
      activeNotifications: filtered.length,
    }));
  };

  const fetchMetrics = async () => {
    try {
      /*
        TODO:
        Replace these queries once lead-program
        assignment tables are finalized.

        For now this follows the same pattern
        as Member Dashboard.
      */

      const currentPrograms = 2;
      const completedPrograms = 1;
      const totalStudents = 18;
      const totalVolunteers = 5;
      const attendanceAverage = 94;
      const pendingBuddyAssignments = 3;

      setMetrics((prev) => ({
        ...prev,
        currentPrograms,
        completedPrograms,
        totalStudents,
        totalVolunteers,
        attendanceAverage,
        pendingBuddyAssignments,
      }));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <>
      <h1 className="text-3xl font-semibold mb-6">My Dashboard</h1>

      {/* Notifications */}

      <h2 className="text-xl font-semibold mb-4">Notifications</h2>

      <div className="space-y-4 mb-10">
        {notifications.length === 0 ? (
          <p className="text-gray-500 text-sm">No notifications available</p>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              className="bg-[#0f5b54] text-white p-4 rounded-lg shadow flex gap-3 items-start"
            >
              <LuInfo className="text-xl mt-1 shrink-0" />

              <div>
                <p className="font-semibold mb-1">{n.title}</p>

                <p className="text-sm text-white/90">{n.message}</p>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Metrics */}

      <h2 className="text-xl font-semibold mb-4">Program Statistics</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <MetricCard title="Current Programs" value={metrics.currentPrograms} />

        <MetricCard
          title="Completed Programs"
          value={metrics.completedPrograms}
        />

        <MetricCard title="Students" value={metrics.totalStudents} />

        <MetricCard title="Volunteers" value={metrics.totalVolunteers} />

        <MetricCard
          title="Attendance Avg"
          value={`${metrics.attendanceAverage}%`}
        />

        <MetricCard
          title="Buddy Assignments"
          value={metrics.pendingBuddyAssignments}
        />

        <MetricCard title="Notifications" value={metrics.activeNotifications} />

        <MetricCard
          title="Lead Since"
          value={
            user?.created_at ? new Date(user.created_at).getFullYear() : "-"
          }
        />
      </div>
    </>
  );
};

export default ProgramLeadDashboard;
