import { useEffect, useState } from "react";
import { supabase } from "../../../../../lib/supabase";

function calculateSubtotal(cart, cycle) {
  if (!cycle) return 0;

  const vocationalPrograms = cart.filter(
    (item) => item.programs?.category?.toLowerCase() === "vocational",
  );

  let total = 0;

  const vocationalCount = vocationalPrograms.length;

  if (vocationalCount === 1) {
    total += Number(cycle.vocational_1_price || 0);
  } else if (vocationalCount === 2) {
    total += Number(cycle.vocational_2_price || 0);
  } else if (vocationalCount >= 3) {
    total += Number(cycle.vocational_3_price || 0);
  }

  cart.forEach((item) => {
    const category = item.programs?.category?.toLowerCase();

    if (category === "employment_services") {
      total += Number(cycle.employment_services_price || 0);
    }

    if (category === "person_centered_services") {
      total += Number(cycle.person_centered_services_price || 0);
    }

    if (
      category === "academic_counseling" ||
      category === "vocational_counseling"
    ) {
      total += Number(cycle.counseling_intake_price || 0);
    }
  });

  return total;
}

export default function EnrollmentCart({
  user,
  cycle,
  cart,
  setCart,
  activeCartId,
  enrolledProgramIds = new Set(),
  remainingSlots = 3,
  onNext,
}) {
  const [programs, setPrograms] = useState([]);
  const [updating, setUpdating] = useState(false);

  async function fetchPrograms() {
    const { data, error } = await supabase
      .from("programs")
      .select("*")
      .eq("academic_year", cycle.year)
      .eq("is_active", true)
      .eq("is_archived", false)
      .order("course_title");

    if (error) {
      console.error(error);
      return;
    }

    setPrograms(data || []);
  }

  /* eslint-disable react-hooks/set-state-in-effect, react-hooks/exhaustive-deps */
  useEffect(() => {
    if (cycle?.id) {
      fetchPrograms();
    }
  }, [cycle]);
  /* eslint-enable react-hooks/set-state-in-effect, react-hooks/exhaustive-deps */

  function isSelected(programId) {
    return cart.some((c) => c.program_id === programId);
  }

  function selectedItem(programId) {
    return cart.find((c) => c.program_id === programId);
  }

  async function toggleProgram(program) {
    if (updating) return;

    setUpdating(true);

    const vocationalCartCount = cart.filter(
      (c) => c.programs?.category?.toLowerCase() === "vocational",
    ).length;

    try {
      if (!activeCartId) {
        alert("Your cart is still loading. Please try again.");
        return;
      }

      const exists = isSelected(program.id);
      const alreadyEnrolled = enrolledProgramIds.has(program.id);

      // MAX 3 PROGRAMS

      if (!exists && alreadyEnrolled) {
        alert("You are already enrolled in this program.");
        return;
      }

      const isVocational = program.category?.toLowerCase() === "vocational";

      if (!exists && isVocational && vocationalCartCount >= remainingSlots) {
        alert(`You can add ${remainingSlots} more vocational program(s).`);
        return;
      }
      // REMOVE FROM CART
      if (exists) {
        const item = selectedItem(program.id);

        if (!item) return;

        if (item.locked) {
          return;
        }

        const { error } = await supabase
          .from("enrollment_cart_items")
          .delete()
          .eq("id", item.id)
          .eq("cart_id", activeCartId)
          .eq("person_id", user.person_id)
          .eq("locked", false);

        if (error) {
          console.error(error);
          return;
        }

        setCart(cart.filter((c) => c.program_id !== program.id));

        return;
      }

      console.log("USER", user);
      console.log("CYCLE", cycle);
      console.log("PROGRAM", program);

      // const { count, error: countError } = await supabase
      //   .from("enrollment_cart_items")
      //   .select("id", {
      //     count: "exact",
      //     head: true,
      //   })
      //   .eq("cart_id", activeCartId)
      //   .eq("person_id", user.person_id);

      // if (countError) {
      //   console.error(countError);
      //   return;
      // }

      if (isVocational && vocationalCartCount >= remainingSlots) {
        alert(`You can add ${remainingSlots} more vocational program(s).`);
        return;
      }

      // ADD TO CART

      const { data, error } = await supabase
        .from("enrollment_cart_items")
        .insert([
          {
            cart_id: activeCartId,

            person_id: user.person_id,

            program_id: program.id,

            registration_setting_id: cycle.id,
          },
        ])
        .select(
          `
        *,
        programs (*)
      `,
        )
        .single();

      if (error) {
        console.error(error);
        if (error.code === "23505") {
          alert("This program is already in your cart.");
        }
        return;
      }

      setCart((prev) => {
        if (prev.some((item) => item.program_id === data.program_id)) {
          return prev;
        }

        return [...prev, data];
      });
    } finally {
      setUpdating(false);
    }
  }

  console.log("SELECTED CYCLE", cycle);
  const subtotal = calculateSubtotal(cart, cycle);

  const vocationalCartCount = cart.filter(
    (item) => item.programs?.category?.toLowerCase() === "vocational",
  ).length;

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 grid md:grid-cols-2 gap-6">
        {programs.map((program) => {
          const selected = isSelected(program.id);
          const locked = selectedItem(program.id)?.locked;
          const alreadyEnrolled = enrolledProgramIds.has(program.id);
          const isVocational = program.category?.toLowerCase() === "vocational";

          const limitReached =
            !selected && isVocational && vocationalCartCount >= remainingSlots;

          return (
            <div
              key={program.id}
              className="bg-white rounded-3xl shadow-sm border p-6"
            >
              <img
                src={program.image_url?.replace("..", "")}
                alt={program.course_title}
                className="w-full h-48 object-contain rounded-2xl"
              />

              <div className="flex items-center gap-3 mt-5">
                <h2 className="text-xl font-semibold">
                  {program.course_title}
                </h2>

                <span
                  className={`px-2 py-1 rounded-full text-xs font-medium ${
                    program.category?.toLowerCase() === "vocational"
                      ? "bg-blue-100 text-blue-700"
                      : "bg-green-100 text-green-700"
                  }`}
                >
                  {program.category}
                </span>
              </div>

              <p className="text-sm text-gray-500 mt-2 line-clamp-3">
                {program.description}
              </p>

              <button
                onClick={() => toggleProgram(program)}
                disabled={updating || locked || alreadyEnrolled || limitReached}
                className={`
                  mt-6
                  w-full
                  py-3
                  rounded-2xl
                  font-medium
                  transition
                  disabled:opacity-50
                  disabled:cursor-not-allowed
                  ${
                    selected
                      ? "bg-red-100 text-red-700"
                      : alreadyEnrolled
                        ? "bg-gray-100 text-gray-600"
                        : "bg-[#0f5b54] text-white"
                  }
                `}
              >
                {updating
                  ? "Updating..."
                  : alreadyEnrolled
                    ? "Already Enrolled"
                    : selected
                      ? "Remove"
                      : "Add to Cart"}
              </button>
            </div>
          );
        })}
      </div>

      <div className="sticky top-6 h-fit bg-white rounded-3xl shadow-sm border p-6">
        <h2 className="text-2xl font-semibold text-[#0f5b54]">Your Cart</h2>

        <div className="space-y-4 mt-6">
          {cart.length === 0 ? (
            <p className="text-gray-500">No programs selected.</p>
          ) : (
            cart.map((item) => (
              <div key={item.id} className="border rounded-2xl p-4">
                <h3 className="font-medium">{item.programs?.course_title}</h3>
              </div>
            ))
          )}
        </div>

        <div className="border-t mt-6 pt-6 space-y-3">
          <div className="flex justify-between">
            <span>Vocational Programs</span>
            <span>
              {vocationalCartCount} / {remainingSlots}
            </span>
          </div>

          <div className="flex justify-between font-semibold text-lg">
            <span>Estimated Total</span>
            <span>${subtotal}</span>
          </div>
        </div>

        <button
          disabled={cart.length === 0 || updating}
          onClick={onNext}
          className="
            mt-6
            w-full
            bg-[#0f5b54]
            text-white
            py-4
            rounded-2xl
            font-medium
          "
        >
          Continue
        </button>
      </div>
    </div>
  );
}

// function calculateSubtotal(cart) {
//   const count = cart.length;

//   if (count === 1) return 250;
//   if (count === 2) return 450;
//   if (count >= 3) return 600;

//   return 0;
// }
